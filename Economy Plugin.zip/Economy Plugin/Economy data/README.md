INSTRUCTIONS--

>>>
>>> GO TO THE CODE AND EDIT THE PATH AT BallanceUtills.java to you're server's plugin folder and >>> create a Folder there called ECONOMY so it can actually create a data file over there to store >>> everyones balance! in Minecraft do /bal or /ballance to know how much money you have!
>>>